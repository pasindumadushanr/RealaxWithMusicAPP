package com.example.madexam02a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.content.Intent

class home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home)

        val searchImageView: ImageView = findViewById(R.id.search)
        searchImageView.setOnClickListener {
            val intent = Intent(this, search::class.java)
            startActivity(intent)
        }

        val favoriteImageView: ImageView = findViewById(R.id.favorite)
        favoriteImageView.setOnClickListener {
            val intent = Intent(this, favorite::class.java)
            startActivity(intent)
        }

        val musicplayerImageView: ImageView = findViewById(R.id.search)
        searchImageView.setOnClickListener {
            val intent = Intent(this, search::class.java)
            startActivity(intent)
        }

        val profileImageView: ImageView = findViewById(R.id.favorite)
        favoriteImageView.setOnClickListener {
            val intent = Intent(this, favorite::class.java)
            startActivity(intent)
        }
    }
}
